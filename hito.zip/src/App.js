import { BrowserRouter ,Routes, Route} from 'react-router-dom';
import './App.css';
import Home from './Components/Home/Home';
import People from './Components/Gente/People';
import Planet from './Components/Planeta/Planet';

function App() {
  
  return (
    <>
     <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/people" element={<People />} />
        <Route path="/planet" element={<Planet />} />
      </Routes>
     </BrowserRouter>
    </>
  );
}

export default App;
