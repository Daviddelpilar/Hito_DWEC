
# Darksides

***** 
Darksiders:
API DE STAR WARS

People: Dentro desse componente nós temos o usetate para setar as pessoas(personagens) na nossa api, dentro dela temos também o useEffect realizando o fetch(busca) na API de pessoas, após isso nós temos o objeto map, responsável por percorrer todo o array de pessoas.
Planet: Dentro desse componente temos o useState para setar  os planetas do universo de star Wars, assim como o useEffect para fazer o fetch(busca) na lista de planetas presentes na api.
Tecnologias utilizadas:
React JS
Sass
API utilizada nesse projeto:
Hooks utilizados:
UseState= Responsável por pegar o estado da nossa aplicação.
UseEffect = Responsável por realizar a  buscar na nossa API.



*****






## Autores

- [@BeneTesla](https://github.com/benetesla)


## Stack utilizada

**Front-end:**
![Reactjs](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![React-router](https://img.shields.io/badge/React_Router-CA4245?style=for-the-badge&logo=react-router&logoColor=white)
![sass](https://img.shields.io/badge/Sass-CC6699?style=for-the-badge&logo=sass&logoColor=white)
![csss](https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E)
## License

[![MIT License](https://img.shields.io/badge/License-MIT-green.svg)](https://choosealicense.com/licenses/mit/)


## 🔗 Entre em contato comigo através dos seguintes meios:

[![portfolio](https://img.shields.io/badge/my_portfolio-000?style=for-the-badge&logo=ko-fi&logoColor=white)](https://bene-teslav1.vercel.app/)

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/bene-tesla/)

[![linkedin](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/bene_tesla/)



## Demonstração
![Captura de Tela (82)](https://user-images.githubusercontent.com/78994881/224776162-80b42a48-08b7-4bac-9835-9c2e7feded32.png)
![Captura de Tela (83)](https://user-images.githubusercontent.com/78994881/224776180-3ac0ba3a-eb4c-4c7d-b2c5-e2c8f88a379a.png)


 


